# SORA Medical

## Care Scenarios currently supported
* Code Blue
* Sepsis
* Stroke

